const CACHE="glycol-watch-v2";
const SHELL=["./index.html","./manifest.webmanifest","./icon.svg"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL))));
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("fetch",e=>{
 const u=new URL(e.request.url);
 if(u.pathname.endsWith("/prices.json")){
   e.respondWith(fetch(e.request).then(r=>{
     const copy=r.clone(); caches.open(CACHE).then(c=>c.put(e.request,copy)); return r;
   }).catch(()=>caches.match(e.request)));
   return;
 }
 e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));
});